import React from "react";

function Shapes(){
     return(
          <>
               hello
          </>
     );
}

export default Shapes;
import React from "react";
import './App.css';
import Footer from "./Footer";
import Header from "./Header";
import Afterhead from "./Afterhead";
import LeftMenu from "./LeftMenu";
import Canvas from "./Canvas";

function App() {
  return (
    <>
      <Header/>
      <Afterhead/>
      {/* Body Part */}
      <div className="container-fluid">
        <div className="row">
          <div className="col-11 mx-auto m-4">
            <div className="row">
              <div className="col-md-3">
                <LeftMenu/>
              </div>
              <div className="col-md-9">
                <Canvas/>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Body Part End */}
      <Footer/>
    </>
  );
}

export default App;
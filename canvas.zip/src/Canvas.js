import React from "react";

function Canvas(){
     return(
          <>
               <div className="row">
                    <div className="col-12">
                         <div className="card">
                              <div className="card-body" style={{height:"600px"}}>
                                   <canvas style={{height:"100%",width:"100%"}}></canvas>
                              </div>
                         </div>
                    </div>
               </div>
          </>
     );
}

export default Canvas;
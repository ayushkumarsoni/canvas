import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faFont } from '@fortawesome/free-solid-svg-icons';

function LeftMenu(props) {
  const { onClickShape } = props;
  return (
    <>
      <div className="row">
        <div className="col-12">
          <div className="card">
            <div className="card-header">
              <h5>Edit Options</h5>
            </div>
            <div className="card-body">
              <nav className="navbar navbar-expand-lg navbar-light bg-white">
                <div className="container">
                  <div className="col-12">
                    <div className="row navbar">
                      <ul className="col-12 navbar-nav flex-column">
                        <li className="nav-item dropdown">
                          <div className="shapes" id="shapesget">
                            <FontAwesomeIcon icon={faFont} /> Shapes
                          </div>
                          <div className="shapes_inner" id="shapes_inner">
                            <div
                              className="circle shapes_item"
                              id="circle"
                              onClick={() => onClickShape('circle')}
                            >
                              <FontAwesomeIcon icon={faFont} /> Circle
                            </div>
                            <div
                              className="rectangle shapes_item"
                              id="rectangle"
                              onClick={() => onClickShape('rect')}
                            >
                              <FontAwesomeIcon icon={faFont} /> Rectangle
                            </div>
                            <div
                              className="text shapes_item"
                              id="text"
                              onClick={() => onClickShape('text')}
                            >
                              <FontAwesomeIcon icon={faFont} /> Text
                            </div>
                          </div>
                        </li>
                        <li>
                          <hr className="dropdown-divider" />
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </nav>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default LeftMenu;

import React, { useCallback, useEffect, useState } from 'react';
import { fabric } from 'fabric';
// import { addReactngle } from './Shapes';

function Canvas(props) {
  const { shapeType } = props;

  useEffect(() => {
    if (window.fabricanvas === undefined) {
      const tempCnvsId = document.getElementById('fabricEditor');
      window.fabricanvas = new fabric.Canvas(tempCnvsId);
    }
  }, []);

  useEffect(() => {
    if (shapeType === 'rect') addReactngle();
    if (shapeType === 'circle') addCircle();
    if (shapeType === 'text') addText();
  }, [shapeType]);

  const addReactngle = useCallback(() => {
    const draw = new fabric.Rect({
      left: 300,
      top: 200,
      fill: 'red',
      width: 150,
      height: 150,
      selectable: true,
    });
    window.fabricanvas.add(draw).renderAll().setActiveObject(draw);
  });

  const addCircle = useCallback(() => {
    const draw = new fabric.Circle({
      left: 30,
      top: 150,
      radius: 20,
      strokeWidth: 1,
      stroke: 'blue',
      selectable: true,
      fill: 'yellow',
      type: 'circle',
      originX: 'left',
      originY: 'top',
    });
    window.fabricanvas.add(draw).renderAll().setActiveObject(draw);
  });

  const addText = useCallback(() => {
    const draw = new fabric.Textbox(`Enter your Text`, {
      fontFamily: 'Arial',
      fontSize: 18,
      textAlign: 'center',
      top: 25,
      left: 10,
      selectable: false,
      evented: false,
      fontWeight: 600,
      breakWords: true,
      //  fixedWidth: 200,
      width: 200,
      // height: 25,
    });
    window.fabricanvas.add(draw).renderAll().setActiveObject(draw);
  });

  return (
    <>
      <div className="row">
        <div className="col-12">
          <div className="card">
            <div className="card-body" style={{ height: '600px' }}>
              <canvas
                id="fabricEditor"
                height="600"
                width="600"
                style={{ height: '100%', width: '100%' }}
              ></canvas>
              {/* {rect && <addReactngle />} */}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Canvas;

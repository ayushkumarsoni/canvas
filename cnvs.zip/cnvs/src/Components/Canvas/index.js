import React, { useState } from 'react';
import LeftMenu from './LeftMenu';
import Canvas from '../Canvas/Canvas';

const CanvasBoard = () => {
  const [shape, setShape] = useState('');

  const hanldeClickShape = (type) => {
    setShape(type);
  };

  return (
    <>
      <div className="col-md-3">
        <LeftMenu onClickShape={hanldeClickShape} />
      </div>
      <div className="col-md-9">
        <Canvas shapeType={shape} />
      </div>
    </>
  );
};

export default CanvasBoard;
